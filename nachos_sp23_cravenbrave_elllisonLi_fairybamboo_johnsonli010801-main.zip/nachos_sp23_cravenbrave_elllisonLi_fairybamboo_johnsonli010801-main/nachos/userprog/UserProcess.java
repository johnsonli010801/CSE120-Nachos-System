package nachos.userprog;

import nachos.machine.*;
import nachos.threads.*;
import nachos.userprog.*;
import nachos.vm.*;

import java.io.EOFException;
import java.io.FileDescriptor;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.HashMap;


/**
 * Encapsulates the state of a user process that is not contained in its user
 * thread (or threads). This includes its address translation state, a file
 * table, and information about the program being executed.
 * 
 * <p>
 * This class is extended by other classes to support additional functionality
 * (such as additional syscalls).
 * 
 * @see nachos.vm.VMProcess
 * @see nachos.network.NetProcess
 */
public class UserProcess {
	/**
	 * Allocate a new process.
	 */
	public UserProcess() {
		fileTable = new OpenFile[16];
		fileTable[0] = UserKernel.console.openForReading();
		fileTable[1] = UserKernel.console.openForWriting();
		Lib.debug(dbgProcess, "new Process created");

		boolean status = Machine.interrupt().disable();
		numProcess++;
		Machine.interrupt().restore(status);

		processCounterLock.acquire();
		pid = ++UserKernel.processPid;
		processCounterLock.release();
		
		childProcesses = new HashMap<>();
		childrenExitStatuses = new HashMap<>();
		pManager = new pipeManager();
		fileDescriptorForPipe = new HashMap<Integer,UserProcess.NamedPipe>();
	}
	private class NamedPipe{
		private final String name;
		private final Queue<Byte> buffer;
		private final Lock lock;
		private boolean isOpen;
		private NamedPipe(String name){
			this.name = name;
			this.buffer = new LinkedList<Byte>();
			this.lock = new Lock();
			this.isOpen = true;
		}
		private int write(byte[]data, int offset,int length){
			lock.acquire();
			//Wait until the pipe is not full
			while(buffer.size()==pageSize)
			{
				lock.release();
				KThread.currentThread().sleep();
				lock.acquire();
			}
			for(int i=0;i<offset+length;i++)
			{
				lock.release();
			}
			return length;
		}
		private int read(byte[]data,int offset, int length){
			lock.acquire();
			//wait until the pipe is not empty
			while(buffer.isEmpty()&&isOpen)
			{
				lock.release();
				KThread.currentThread().sleep();
				lock.acquire();
			}
			int totalAmountByteread = 0;
			while(totalAmountByteread<length&&!buffer.isEmpty())
			{
				data[offset+totalAmountByteread]= buffer.poll();
				totalAmountByteread++;
			}
			lock.release();
			return totalAmountByteread;
		}
		private void close(){
			lock.acquire();
			isOpen = false;
			lock.release();
		}

	}
	//helper class for managing pipe
	private class pipeManager{
		private final Map<String,NamedPipe>namedpipe;
		private final Lock lock;
		private pipeManager(){
			this.namedpipe = new HashMap<String,UserProcess.NamedPipe>();
			this.lock = new Lock();
		}
		private NamedPipe createNamedPipe(String name){
			lock.acquire();
			//check whether the pipe exist
			if(namedpipe.containsKey(name))
			{
				lock.release();
				return null;
			}
			if(namedpipe.size()>=16)
			{
				lock.release();
				return null;
			}
			NamedPipe pipe = new NamedPipe(name);
			lock.release();
			return pipe;
		}
		private NamedPipe openPipe(String name){
			lock.acquire();
			NamedPipe pipe = namedpipe.get(name);
			lock.release();
			return pipe;
		}
		private void closePipe(String name)
		{
			lock.acquire();
			namedpipe.remove(name);
			lock.release();
		}
	}

	/**
	 * Allocate and return a new process of the correct class. The class name is
	 * specified by the <tt>nachos.conf</tt> key
	 * <tt>Kernel.processClassName</tt>.
	 * 
	 * @return a new process of the correct class.
	 */
	public static UserProcess newUserProcess() {
	    String name = Machine.getProcessClassName ();

		// If Lib.constructObject is used, it quickly runs out
		// of file descriptors and throws an exception in
		// createClassLoader.  Hack around it by hard-coding
		// creating new processes of the appropriate type.

		if (name.equals ("nachos.userprog.UserProcess")) {
		    return new UserProcess ();
		} else if (name.equals ("nachos.vm.VMProcess")) {
		    return new VMProcess ();
		} else {
		    return (UserProcess) Lib.constructObject(Machine.getProcessClassName());
		}
	}

	/**
	 * Execute the specified program with the specified arguments. Attempts to
	 * load the program, and then forks a thread to run it.
	 * 
	 * @param name the name of the file containing the executable.
	 * @param args the arguments to pass to the executable.
	 * @return <tt>true</tt> if the program was successfully executed.
	 */
	public boolean execute(String name, String[] args) {
		if (!load(name, args)) {
			System.out.println("Load fail");
			unloadSections();
			return false;
		}

		thread = new UThread(this);
		thread.setName(name).fork();

		return true;
	}

	/**
	 * Save the state of this process in preparation for a context switch.
	 * Called by <tt>UThread.saveState()</tt>.
	 */
	public void saveState() {
	}

	/**
	 * Restore the state of this process after a context switch. Called by
	 * <tt>UThread.restoreState()</tt>.
	 */
	public void restoreState() {
		Machine.processor().setPageTable(pageTable);
	}

	/**
	 * Read a null-terminated string from this process's virtual memory. Read at
	 * most <tt>maxLength + 1</tt> bytes from the specified address, search for
	 * the null terminator, and convert it to a <tt>java.lang.String</tt>,
	 * without including the null terminator. If no null terminator is found,
	 * returns <tt>null</tt>.
	 * 
	 * @param vaddr the starting virtual address of the null-terminated string.
	 * @param maxLength the maximum number of characters in the string, not
	 * including the null terminator.
	 * @return the string read, or <tt>null</tt> if no null terminator was
	 * found.
	 */
	public String readVirtualMemoryString(int vaddr, int maxLength) {
		Lib.assertTrue(maxLength >= 0);

		byte[] bytes = new byte[maxLength + 1];

		int bytesRead = readVirtualMemory(vaddr, bytes);

		for (int length = 0; length < bytesRead; length++) {
			if (bytes[length] == 0)
				return new String(bytes, 0, length);
		}

		return null;
	}

	/**
	 * Transfer data from this process's virtual memory to all of the specified
	 * array. Same as <tt>readVirtualMemory(vaddr, data, 0, data.length)</tt>.
	 * 
	 * @param vaddr the first byte of virtual memory to read.
	 * @param data the array where the data will be stored.
	 * @return the number of bytes successfully transferred.
	 */
	public int readVirtualMemory(int vaddr, byte[] data) {
		return readVirtualMemory(vaddr, data, 0, data.length);
	}

	/**
	 * Transfer data from this process's virtual memory to the specified array.
	 * This method handles address translation details. This method must
	 * <i>not</i> destroy the current process if an error occurs, but instead
	 * should return the number of bytes successfully copied (or zero if no data
	 * could be copied).
	 * 
	 * @param vaddr the first byte of virtual memory to read.
	 * @param data the array where the data will be stored.
	 * @param offset the first byte to write in the array.
	 * @param length the number of bytes to transfer from virtual memory to the
	 * array.
	 * @return the number of bytes successfully transferred.
	 */
	public int readVirtualMemory(int vaddr, byte[] data, int offset, int length) {
		Lib.assertTrue(offset >= 0 && length >= 0
				&& offset + length <= data.length);

		byte[] memory = Machine.processor().getMemory();

		int currentVaddr = vaddr;

		int totalbytes=0;
		while(length > 0)
		{
			int currvpn = Processor.pageFromAddress(currentVaddr);
			//check vpn is valid
			if (currvpn >= numPages) {
				return 0;
			}

			//return number of bytes that already read bytes back
			if (!pageTable[currvpn].valid) {
				break;
			}

			int currppn = pageTable[currvpn].ppn;
			int newOffset = Processor.offsetFromAddress(currentVaddr);

			//get physical address
			int pAddr = Machine.processor().makeAddress(currppn, newOffset);

			//check physical address is valid
			if (pAddr < 0 || pAddr >= memory.length) {
				return 0;
			}
			
			int nextVaddr = Machine.processor().makeAddress(currvpn + 1, 0);
			// int pageAddr = pageSize*currppn+newOffset;

			//bytes to read, page size - offset means the bytes left in this page
			//read the whole left page or length, whichever is smaller
			int amount = Math.min(length, pageSize - newOffset);
			// if(nextVaddr< vaddr+length&& nextVaddr<numPages*pageSize)
			// {
			// 	amount = nextVaddr - currentVaddr;
			// }
			// else{
			// 	 amount = Math.min(length+vaddr, numPages*pageSize);
			// }
			System.arraycopy(memory, pAddr, data, offset, amount);

			currentVaddr = nextVaddr;
			offset+=amount;
			length-=amount;
			totalbytes+=amount;
		}

		return totalbytes;
	}

	/**
	 * Transfer all data from the specified array to this process's virtual
	 * memory. Same as <tt>writeVirtualMemory(vaddr, data, 0, data.length)</tt>.
	 * 
	 * @param vaddr the first byte of virtual memory to write.
	 * @param data the array containing the data to transfer.
	 * @return the number of bytes successfully transferred.
	 */
	public int writeVirtualMemory(int vaddr, byte[] data) {
		return writeVirtualMemory(vaddr, data, 0, data.length);
	}

	/**
	 * Transfer data from the specified array to this process's virtual memory.
	 * This method handles address translation details. This method must
	 * <i>not</i> destroy the current process if an error occurs, but instead
	 * should return the number of bytes successfully copied (or zero if no data
	 * could be copied).
	 * 
	 * @param vaddr the first byte of virtual memory to write.
	 * @param data the array containing the data to transfer.
	 * @param offset the first byte to transfer from the array.
	 * @param length the number of bytes to transfer from the array to virtual
	 * memory.
	 * @return the number of bytes successfully transferred.
	 */
	public int writeVirtualMemory(int vaddr, byte[] data, int offset, int length) {
		Lib.assertTrue(offset >= 0 && length >= 0
				&& offset + length <= data.length);

		byte[] memory = Machine.processor().getMemory();

		int currentVaddr = vaddr;
		int totalbytes=0;
		// while(currentVaddr<numPages*pageSize&&currentVaddr<vaddr+length)
		while(length > 0)
		{
			int currvpn = Processor.pageFromAddress(currentVaddr);
			//check vpn is valid
			if (currvpn >= numPages) return 0;
			//return number of bytes that alrady write data back
			if (!pageTable[currvpn].valid || pageTable[currvpn].readOnly) break;
			
			int currppn = pageTable[currvpn].ppn;
			int newOffset = Processor.offsetFromAddress(currentVaddr);
			
			//get physical address
			int pAddr = Machine.processor().makeAddress(currppn, newOffset);
			//check physical address is valid
			if (pAddr < 0 || pAddr >= memory.length) return 0;

			int nextVaddr = Machine.processor().makeAddress(currvpn + 1, 0);
			// int pageAddr = pageSize*currppn+newOffset;

			//bytes to read, page size - offset means the bytes left in this page
			//read the whole left page or length, whichever is smaller
			int amount = Math.min(length, pageSize - newOffset);
			// if(nextVaddr< vaddr+length&& nextVaddr<numPages*pageSize)
			// {
			// 	amount = nextVaddr - currentVaddr;
			// }
			// else{
			// 	 amount = Math.min(length+vaddr, numPages*pageSize)-currentVaddr;
			// }
			System.arraycopy(data, offset, memory, pAddr, amount);

			currentVaddr = nextVaddr;
			offset+=amount;
			length-=amount;
			totalbytes+=amount;
		}
		return totalbytes;
	}

	/**
	 * Load the executable with the specified name into this process, and
	 * prepare to pass it the specified arguments. Opens the executable, reads
	 * its header information, and copies sections and arguments into this
	 * process's virtual memory.
	 * 
	 * @param name the name of the file containing the executable.
	 * @param args the arguments to pass to the executable.
	 * @return <tt>true</tt> if the executable was successfully loaded.
	 */
	private boolean load(String name, String[] args) {
		Lib.debug(dbgProcess, "UserProcess.load(\"" + name + "\")");

		OpenFile executable = ThreadedKernel.fileSystem.open(name, false);
		if (executable == null) {
			Lib.debug(dbgProcess, "\topen failed");
			return false;
		}
		
		try {
			coff = new Coff(executable);
		}
		catch (EOFException e) {
			executable.close();
			Lib.debug(dbgProcess, "\tcoff load failed");
			return false;
		}

		// make sure the sections are contiguous and start at page 0
		numPages = 0;
		for (int s = 0; s < coff.getNumSections(); s++) {
			CoffSection section = coff.getSection(s);
			if (section.getFirstVPN() != numPages) {
				coff.close();
				Lib.debug(dbgProcess, "\tfragmented executable");
				return false;
			}
			numPages += section.getLength();
		}

		// make sure the argv array will fit in one page
		byte[][] argv = new byte[args.length][];
		int argsSize = 0;
		for (int i = 0; i < args.length; i++) {
			argv[i] = args[i].getBytes();
			// 4 bytes for argv[] pointer; then string plus one for null byte
			argsSize += 4 + argv[i].length + 1;
		}
		if (argsSize > pageSize) {
			coff.close();
			Lib.debug(dbgProcess, "\targuments too long");
			return false;
		}

		// program counter initially points at the program entry point
		initialPC = coff.getEntryPoint();

		// next comes the stack; stack pointer initially points to top of it
		numPages += stackPages;
		initialSP = numPages * pageSize;

		// and finally reserve 1 page for arguments
		numPages++;

		// System.out.println("Try initialize pagetable");
		// if(!initialPageTable())
		// 	return false;

		//System.out.println("try loadsection");
		if (!loadSections())
			return false;

		// store arguments in last page
		int entryOffset = (numPages - 1) * pageSize;
		int stringOffset = entryOffset + args.length * 4;

		this.argc = args.length;
		this.argv = entryOffset;

		for (int i = 0; i < argv.length; i++) {
			byte[] stringOffsetBytes = Lib.bytesFromInt(stringOffset);
			Lib.assertTrue(writeVirtualMemory(entryOffset, stringOffsetBytes) == 4);
			entryOffset += 4;
			Lib.assertTrue(writeVirtualMemory(stringOffset, argv[i]) == argv[i].length);
			stringOffset += argv[i].length;
			Lib.assertTrue(writeVirtualMemory(stringOffset, new byte[] { 0 }) == 1);
			stringOffset += 1;
		}

		return true;
	}

	// /**
	//  * Initialize the page table, the length of page table is numPages Used in proj2
	//  */
	// private boolean initialPageTable() {
	// 	pageTable = new TranslationEntry[numPages];
	// 	UserKernel.pageAllocate.acquire();
	// 	for (int i = 0; i < numPages; i++) {
	// 		int ppn = UserKernel.getFreePhysPage();  // if ppn == -1, no enough physical pages to use: return false
	// 		if (ppn == -1) { return false; }
	// 		pageTable[i] = new TranslationEntry(i, ppn, true, false, false, false);
	// 	}
	// 	UserKernel.pageAllocate.release();
	// 	return true;
	// }

	/**
	 * Allocates memory for this process, and loads the COFF sections into
	 * memory. If this returns successfully, the process will definitely be run
	 * (this is the last step in process initialization that can fail).
	 * 
	 * @return <tt>true</tt> if the sections were successfully loaded.
	 */
	protected boolean loadSections() {
		if (numPages > Machine.processor().getNumPhysPages()) {
			coff.close();
			Lib.debug(dbgProcess, "\tinsufficient physical memory");
			return false;
		}
		loadLock.acquire();

		// load sections
		for (int s = 0; s < coff.getNumSections(); s++) {
			CoffSection section = coff.getSection(s);

			Lib.debug(dbgProcess, "\tinitializing " + section.getName()
					+ " section (" + section.getLength() + " pages)");

			for (int i = 0; i < section.getLength(); i++) {
				int vpn = section.getFirstVPN() + i;
				if(pageTable[vpn]==null)
				{
					loadLock.release();
					return false;
				}
				UserKernel.pageAllocate.acquire();
				pageTable[vpn].readOnly = section.isReadOnly();	
				section.loadPage(i, pageTable[vpn].ppn);
				UserKernel.pageAllocate.release();
			}
		}

		loadLock.release();
		return true;
	}

	/**
	 * Release any resources allocated by <tt>loadSections()</tt>.
	 */
	protected void unloadSections() {
		//to free all the used physical page
		for(int i=0;i<numPages;i++)
		{
			loadLock.acquire();
			UserKernel.pagesFree.add(pageTable[i].ppn);
			pageTable[i].valid = false;
			loadLock.release();
		}
	}

	/**
	 * Initialize the processor's registers in preparation for running the
	 * program loaded into this process. Set the PC register to point at the
	 * start function, set the stack pointer register to point at the top of the
	 * stack, set the A0 and A1 registers to argc and argv, respectively, and
	 * initialize all other registers to 0.
	 */
	public void initRegisters() {
		Processor processor = Machine.processor();

		// by default, everything's 0
		for (int i = 0; i < processor.numUserRegisters; i++)
			processor.writeRegister(i, 0);

		// initialize PC and SP according
		processor.writeRegister(Processor.regPC, initialPC);
		processor.writeRegister(Processor.regSP, initialSP);

		// initialize the first two argument registers to argc and argv
		processor.writeRegister(Processor.regA0, argc);
		processor.writeRegister(Processor.regA1, argv);
	}
	//helper method for checking whether ispipefiledescriptor or not
	private boolean ispipefiledescriptor(int fd)
	{
		if(fileDescriptorForPipe.containsKey(fd)){
			Object file = fileDescriptorForPipe.get(fd);
			if(file instanceof NamedPipe)
			{
				return true;
			}
		}
		return false;
	}
	//helper method for checking whether ispipe file
	private boolean ispipeFile(String name){
		if(name.contains("/pipe/"))
		{
			return true;
		}
		return false;
	}
	/**
	 * Handle the creat() system call.
	 */
	private int handleCreat(int name){
		String fileName = readVirtualMemoryString(name,256);
		if(fileName==null){
			System.out.println("[Error-handleCreat]: no valid filename");
			return -1;
		}
		
		//find a free file descriptor
		int index = -1;
		for(int i=2; i<fileTable.length; i++){
			if(fileTable[i] == null){
				index = i;
				break;
			}
		}
		if(index == -1){
			System.out.println("[Error-handleCreat]: no free file descriptor");
			return -1;
		}

		// link file descriptor and file
		OpenFile tmpFile = Machine.stubFileSystem().open(fileName, true);
		if(tmpFile == null){
			System.out.println("[Error-handleCreat]: no file in the file system");
			return -1;
		}else{
			//checking whether it is a pipe file
			if(ispipeFile(fileName)==true)
			{
				NamedPipe pipe = pManager.createNamedPipe(fileName);
				//double checking the pipe is not null
				if(pipe==null)
				{
					return -1;
				}
				fileTable[index]=tmpFile;
				fileDescriptorForPipe.put(index, pipe);
				return index;
			}
			// link
			System.out.println("[Success-handleCreat]:  file: "+fileName+" created at index: "+index+" in the table");
			fileTable[index] = tmpFile;
			return index;
		}
	}

	/**
	 * Handle the open() system call.
	 */
	private int handleOpen(int name){
		String fileName = readVirtualMemoryString(name,256);
		if(fileName==null){
			System.out.println("[Error-handleOpen]: no valid filename");
			return -1;
		}
		
		//find a free file descriptor
		int index = -1;
		for(int i=2; i<fileTable.length; i++){
			if(fileTable[i] == null){
				index = i;
				break;
			}
		}
		if(index == -1){
			System.out.println("[Error-handleOpen]: no free file descriptor");
			return -1;
		}

		// link file descriptor and file
		OpenFile tmpFile = Machine.stubFileSystem().open(fileName, false);
		if(tmpFile == null){
			System.out.println("[Error-handleOpen]: no file in the file system");
			return -1;
		}else{
			//handle for pipe file
			if(ispipeFile(fileName)==true)
			{
				currNamedPipe = pManager.openPipe(fileName);
				if(currNamedPipe ==null)
				{
					return -1;
				}
				fileTable[index]=tmpFile;
				fileDescriptorForPipe.put(index, currNamedPipe);
				return index;
			}
			// link
			System.out.println("[Success-handleOpen]: open file: "+ fileName);
			fileTable[index] = tmpFile;
			return index;
		}
	}

	/**
	 * Handle the read() system call.
	 */
	private int handleRead(int fileDescriptor, int bufferAddr, int count){
		// check file descriptor
		if(fileDescriptor<0 || fileDescriptor>15){
			System.out.println("[Error-handleRead]: file descriptor is invalid");
			return -1;
		}

		if(fileDescriptor>1 && fileTable[fileDescriptor] == null){
			System.out.println("[Error-handleRead]: file descriptor links to null file");
			return -1;
		}

		// check count
		if(count<0){
			System.out.println("[Error-handleRead]: invalid count, count is negative");
			return -1;
		}
		if(count == 0){
			return 0;
		}
		if(ispipefiledescriptor(fileDescriptor)){
			if(currNamedPipe ==null)
			{
				return -1;
			}
			return currNamedPipe.read(new byte[pageSize],0,Math.min(count, pageSize));
		}
		// read
		int totalBytesRead = 0;
		int numBytesRead = 0;
		byte[] buf = new byte[pageSize];
		OpenFile openFile = fileTable[fileDescriptor];
		while(count>0){
			//read from file/stream
			int numToRead = Math.min(count,pageSize);
			numBytesRead = openFile.read(buf,0,numToRead);
			if(numBytesRead == -1){
				System.out.println("[Error-handleRead]: no bytes could be read because of a fatal error");
				return -1;
			}
			// write into buffer
			int numBytesWritten = writeVirtualMemory(bufferAddr,buf,0,numBytesRead);
			if(numBytesWritten > numBytesRead){
				System.out.println("[Error-handleRead]: error in writting into virtual memory");
				return -1;
			}
			bufferAddr = bufferAddr + numBytesWritten;
			totalBytesRead = totalBytesRead + numBytesWritten;
			count = count - numBytesWritten;
		}

		System.out.println("[Success-handleRead]: read "+totalBytesRead+" bytes");
		return totalBytesRead;
	}

	/**
	 * Handle the write() system call.
	 */
	private int handleWrite(int fileDescriptor, int bufferAddr, int count){
		// check file descriptor
		if(fileDescriptor<0 || fileDescriptor>15){
			System.out.println("[Error-handleWrite]: file descriptor is invalid");
			return -1;
		}

		if(fileDescriptor>1 && fileTable[fileDescriptor] == null){
			System.out.println("[Error-handleWrite]: file descriptor links to null file");
			return -1;
		}

		// check count
		if(count<0){
			System.out.println("[Error-handleWrite]: invalid count, count is negative");
			return -1;
		}
		if(count == 0){
			return 0;
		}
		if(ispipefiledescriptor(fileDescriptor)){
			if(currNamedPipe ==null)
			{
				return -1;
			}
			return currNamedPipe.write(new byte[pageSize], 0, Math.min(count,pageSize));
		}
		// write
		int numRequested = count;
		int totalBytesWritten = 0;
		int numBytesWritten = 0;
		byte[] buf = new byte[pageSize];
		OpenFile openFile = fileTable[fileDescriptor];
		while(count>0){
			// read from buffer
			int numToWrite = Math.min(count,pageSize);
			int numBytesRead = readVirtualMemory(bufferAddr,buf,0,numToWrite);
			if(numBytesRead == -1 || numBytesRead != numToWrite){
				System.out.println("[Error-handleWrite]: error in reading from virtual memory");
				return -1;
			}
			// write into file/stream 
			numBytesWritten = openFile.write(buf,0,numBytesRead);
			if(numBytesWritten == -1){
				System.out.println("[Error-handleWrite]: no bytes could be written because of a fatal error");
				return -1;
			}
			if(numBytesWritten != numBytesRead){
				System.out.println("[Error-handleWrite]: read and write don't match");
				return -1;
			}

			totalBytesWritten += numBytesWritten;
			count -= numBytesWritten;
			bufferAddr += numBytesWritten;	
		}
		if(totalBytesWritten < numRequested){
			System.out.println("[Error-handleWrite]: the number of written bytes is smaller than the number of bytes requested");
			return -1;
		}

		System.out.println("[Success-handleWrite]: write "+totalBytesWritten+" bytes");
		return totalBytesWritten;

	}

	/**
	 * Handle the close() system call.
	 */
	private int handleClose(int fileDescriptor){
		//check fileDescriptor
		if(fileDescriptor<0 || fileDescriptor>15){
			System.out.println("[Error-handleClose]: file descriptor is invalid");
			return -1;
		}
		if(fileTable[fileDescriptor]==null){
			System.out.println("[Error-handleClose]: descriptor links to a null file");
			return -1;
		}
		Object file = fileDescriptorForPipe.get(fileDescriptor);
		if(file instanceof NamedPipe)
		{
			NamedPipe pipe = (NamedPipe)file;
			pipe.close();
			pManager.closePipe(pipe.name);
			fileDescriptorForPipe.remove(fileDescriptor);
			return 0;
		}

		//close
		fileTable[fileDescriptor].close();
		fileTable[fileDescriptor] = null;
		System.out.println("[Success-handleClose]");
		return 0;
	}

	/**
	 * Handle the unlink() system call.
	 */
	private int handleUnlink(int name){
		String fileName = readVirtualMemoryString(name,256);
		boolean successful = Machine.stubFileSystem().remove(fileName);
		if(successful){
			System.out.println("[Success-handleUnlink]");
			return 0;
		}else{
			System.out.println("[Error-handleUnlink]");
			return -1;
		}
	}

	/**
	 * Handle the halt() system call.
	 */
	private int handleHalt() {
		//only can be invoked by the root process
		if(this.pid == 1) {
			Machine.halt();
			Lib.assertNotReached("Machine.halt() did not halt machine!");
			return 0;
		}
		return -1;
	}

	/**
	 * Handle the exec() system call.
	 */	
	private int handleExec(int fileName, int argc, int argv) {
		Lib.debug(dbgProcess, "handleExec running " + this.pid);
		Lib.debug(dbgProcess, "handleExec running processnum " + numProcess);

		if(argc < 0) {
			Lib.debug(dbgProcess, "handleExec, argc");
			return -1;
		}
		
		String filename = readVirtualMemoryString(fileName, 256);
		if(filename == null) {
			Lib.debug(dbgProcess, "handleExec, filename");
			return -1;
		}
		
		//store arguments for exec
		String[] args = new String[argc];
		byte[] buffer = new byte[4]; 
		for(int i = 0; i < argc; ++i) {
			//32-bit address
			//get the pointer(address) of this argument
			if(readVirtualMemory(argv + i * 4, buffer) != 4) {
				Lib.debug(dbgProcess, "handleExec, vmRead");
				return -1;
			};
			//get the actual argument
			String thisArg = readVirtualMemoryString(Lib.bytesToInt(buffer, 0), 256);
			if(thisArg == null) {
				Lib.debug(dbgProcess, "handleExec, arg");
				return -1;
			}
			args[i] = thisArg;
		}

		//create a new process and try to execute
		UserProcess child = newUserProcess();
		if(!child.execute(filename, args)) {
			Lib.debug(dbgProcess, "handleExec, exec fail");
			return -1;
		}

		//child's parent is the caller
		child.parentProcess = this;
		//one parent can have many children
		this.childProcesses.put(child.pid, child);
		//returns the child process's process ID. On error, returns -1.
		return child.pid;
	}

	/**
	 * Handle the join() system call.
	 */
	private int handleJoin(int childPID, int status_addr) {
		//If processID does not refer to a child process of the current process, returns -1.
		if(!childProcesses.containsKey(childPID)) {
			System.out.println("Id " + childPID + "Not a child");
			return -1;
		}

		/*If the status parameter is invalid (e.g., beyond the end of the address space), 
		  then join immediately returns with -1 to indicate an error.*/
		if(status_addr > pageTable.length * pageSize) { 
			System.out.println("address out of bound");
			return -1;
		}

		UserProcess child = childProcesses.get(childPID);

		childProcesses.remove(childPID);

		if(child == null) {
			System.out.println("child is null");
			return -1;
		}

		child.thread.join();

		Integer exitStatus = childrenExitStatuses.get(child);
		
		//unhandled exception
		if(exitStatus == null) {
			return 0;
		}

		//store the exitStatus to the corresponding address
		byte[] buffer = Lib.bytesFromInt(exitStatus);
		if(writeVirtualMemory(status_addr, buffer) != 4) {
			return 0;
		}

		return 1;
	}

	/**
	 * Handle the exit() system call.
	 */
	private int handleExit(int status) {
	    // Do not remove this call to the autoGrader...
		Machine.autoGrader().finishingCurrentProcess(status);
		// ...and leave it as the top of handleExit so that we
		// can grade your implementation.
		System.out.println("Status" + status);
		//close all file
		for (int i = 2; i < fileTable.length; ++i) {
			if (fileTable[i] != null) {
				handleClose(i);
			}
		}

		unloadSections();

		//close the program
		coff.close();

		//handle this process's father 
		if(parentProcess != null) {
			System.out.println("Parent Process pid: " + parentProcess.pid);
			if(exception) {
				parentProcess.childrenExitStatuses.put(this, null);
			} else {
				parentProcess.childrenExitStatuses.put(this, status);
			}
		}

		//handle this process's children
		for(UserProcess child: childProcesses.values()) {
			child.parentProcess = null;
		}

		boolean interruptStatus = Machine.interrupt().disable();
		numProcess--; 
		Machine.interrupt().restore(interruptStatus);

		if(numProcess == 0) {
			Kernel.kernel.terminate();
		}

		KThread.finish();
	
		return 0;
	}

	private static final int syscallHalt = 0, syscallExit = 1, syscallExec = 2,
			syscallJoin = 3, syscallCreate = 4, syscallOpen = 5,
			syscallRead = 6, syscallWrite = 7, syscallClose = 8,
			syscallUnlink = 9;

	/**
	 * Handle a syscall exception. Called by <tt>handleException()</tt>. The
	 * <i>syscall</i> argument identifies which syscall the user executed:
	 * 
	 * <table>
	 * <tr>
	 * <td>syscall#</td>
	 * <td>syscall prototype</td>
	 * </tr>
	 * <tr>
	 * <td>0</td>
	 * <td><tt>void halt();</tt></td>
	 * </tr>
	 * <tr>
	 * <td>1</td>
	 * <td><tt>void exit(int status);</tt></td>
	 * </tr>
	 * <tr>
	 * <td>2</td>
	 * <td><tt>int  exec(char *name, int argc, char **argv);
	 * 								</tt></td>
	 * </tr>
	 * <tr>
	 * <td>3</td>
	 * <td><tt>int  join(int pid, int *status);</tt></td>
	 * </tr>
	 * <tr>
	 * <td>4</td>
	 * <td><tt>int  creat(char *name);</tt></td>
	 * </tr>
	 * <tr>
	 * <td>5</td>
	 * <td><tt>int  open(char *name);</tt></td>
	 * </tr>
	 * <tr>
	 * <td>6</td>
	 * <td><tt>int  read(int fd, char *buffer, int size);
	 * 								</tt></td>
	 * </tr>
	 * <tr>
	 * <td>7</td>
	 * <td><tt>int  write(int fd, char *buffer, int size);
	 * 								</tt></td>
	 * </tr>
	 * <tr>
	 * <td>8</td>
	 * <td><tt>int  close(int fd);</tt></td>
	 * </tr>
	 * <tr>
	 * <td>9</td>
	 * <td><tt>int  unlink(char *name);</tt></td>
	 * </tr>
	 * </table>
	 * 
	 * @param syscall the syscall number.
	 * @param a0 the first syscall argument.
	 * @param a1 the second syscall argument.
	 * @param a2 the third syscall argument.
	 * @param a3 the fourth syscall argument.
	 * @return the value to be returned to the user.
	 */
	public int handleSyscall(int syscall, int a0, int a1, int a2, int a3) {
		switch (syscall) {
		case syscallHalt:
			return handleHalt();
		case syscallExit:
			return handleExit(a0);
		case syscallCreate:
			return handleCreat(a0);
		case syscallOpen:
			return handleOpen(a0);
		case syscallRead:
			return handleRead(a0,a1,a2);
		case syscallWrite:
			return handleWrite(a0,a1,a2);
		case syscallClose:
			return handleClose(a0);
		case syscallUnlink:
			return handleUnlink(a0);
		case syscallExec:
			return handleExec(a0, a1, a2);
		case syscallJoin:
			return handleJoin(a0, a1);

		default:
			Lib.debug(dbgProcess, "Unknown syscall " + syscall);
			Lib.assertNotReached("Unknown system call!");
		}
		return 0;
	}

	/**
	 * Handle a user exception. Called by <tt>UserKernel.exceptionHandler()</tt>
	 * . The <i>cause</i> argument identifies which exception occurred; see the
	 * <tt>Processor.exceptionZZZ</tt> constants.
	 * 
	 * @param cause the user exception that occurred.
	 */
	public void handleException(int cause) {
		Processor processor = Machine.processor();
		System.out.println("User Process exception handler");

		switch (cause) {
		case Processor.exceptionSyscall:
			int result = handleSyscall(processor.readRegister(Processor.regV0),
					processor.readRegister(Processor.regA0),
					processor.readRegister(Processor.regA1),
					processor.readRegister(Processor.regA2),
					processor.readRegister(Processor.regA3));
			processor.writeRegister(Processor.regV0, result);
			processor.advancePC();
			break;

		default:
			Lib.debug(dbgProcess, "Unexpected exception: "
					+ Processor.exceptionNames[cause]);
			exception = true;
			handleExit(cause);
			Lib.assertNotReached("Unexpected exception");
		}
	}

	/** The program being run by this process. */
	protected Coff coff;

	/** This process's page table. */
	public TranslationEntry[] pageTable;

	/** The number of contiguous pages occupied by the program. */
	protected int numPages;

	/** The number of pages in the program's stack. */
	protected final int stackPages = 8;

	/** The thread that executes the user-level program. */
    protected UThread thread;
    
	private int initialPC, initialSP;

	private int argc, argv;

	private static final int pageSize = Processor.pageSize;

	private static final char dbgProcess = 'a';

	private UserProcess parentProcess;
	private int pid;
	private static int numProcess;
	private boolean exception = false; //tell exit that the process has exceptions
	private HashMap<UserProcess, Integer> childrenExitStatuses;
	private HashMap<Integer, UserProcess> childProcesses;

	protected OpenFile[] fileTable;
	private Lock processCounterLock = new Lock();

	protected static Lock loadLock = new Lock();
	private NamedPipe currNamedPipe;
	private pipeManager pManager;
	private HashMap<Integer,NamedPipe> fileDescriptorForPipe;
}
