package nachos.threads;

import java.util.HashMap;
import java.util.*;

import nachos.machine.*;

/**
 * A <i>Rendezvous</i> allows threads to synchronously exchange values.
 */
public class Rendezvous {

    //used to lock the condition
    private Lock lock;
    //used to store the lock
    private Condition exchangeCon;
    //used to evaluate whether the exchange is waiting for another thread
    private boolean isExchanging;

    //used to store the condition for each thread
    Map<Integer, Condition> threadCons;
    //used to store the threads we are waiting for exchanging
    Set<Integer> threadSet;
    //used to store the values for each thread for exchanging
    Map<Integer, Integer> threadVals;

    /**
     * Allocate a new Rendezvous.
     */
    public Rendezvous () {
        //initialize all variables
        lock = new Lock();
        exchangeCon = new Condition(lock);
        isExchanging = false;

        threadCons = new HashMap<Integer,Condition>();
        threadSet = new HashSet<Integer>();
        threadVals = new HashMap<Integer,Integer>();
    }

    /**
     * Synchronously exchange a value with another thread.  The first
     * thread A (with value X) to exhange will block waiting for
     * another thread B (with value Y).  When thread B arrives, it
     * will unblock A and the threads will exchange values: value Y
     * will be returned to thread A, and value X will be returned to
     * thread B.
     *
     * Different integer tags are used as different, parallel
     * synchronization points (i.e., threads synchronizing at
     * different tags do not interact with each other).  The same tag
     * can also be used repeatedly for multiple exchanges.
     *
     * @param tag the synchronization tag.
     * @param value the integer to exchange.
     */
    public int exchange (int tag, int value) {
        lock.acquire();
        System.out.println("--------------------");
        System.out.println("Now the status of isExchange is " + isExchanging + " Thread name is: " + KThread.currentThread().getName());
       
        //wait for the last exchange to finish
        while (isExchanging) {
            exchangeCon.sleep();
        }

        //if it's not waiting for exchanging, then we need to check whether we have the thread we are waiting for
        //if we do not have, then add it to the threadSet and threadCons
        if (!threadSet.contains(tag)) {
            System.out.println("Thread name is " + KThread.currentThread().getName() + " tag value:" + tag + " is NOT in the threadSet");
            System.out.println("tag value:" + tag);
            //add the thread to the threadSet
            threadSet.add(tag);
            //store the value we want to exchange
            threadVals.put(tag, value);

            //create new condition with same lock for the thread, and add them to the threadCons
            Condition tagCon = new Condition(lock);
            threadCons.put(tag, tagCon);

            //onhold the thread
            tagCon.sleep();

            System.out.println("Thread name is " + KThread.currentThread().getName() + " is WAKEN UP, non exisiting tag" + tag);
            //set isExchanging to false, allow other exchanges with same tag number
            isExchanging = false;
            threadSet.remove(tag);
            //we might have multiple threads waiting for exchanging, so we need to wake all of them up
            System.out.println("I am going to wake up all the threads!!!!!");
            exchangeCon.wakeAll(); 
        } else { // if we have the thread that are waiting for
            Condition tagCon = threadCons.get(tag);
            //wake up the thread
            tagCon.wake();
            System.out.println("Thread name is " + KThread.currentThread().getName() + " is WAKEN UP, exisiting tag" + tag);

            //set isExchanging to true, start exchanging with current two threads
            isExchanging = true;
        }

        //start value exchanging
        //return A's value
        int res = threadVals.get(tag);
        //set B's value to A
        threadVals.put(tag, value);
        
        lock.release();

        System.out.println("Exchange finished, thread name is " + KThread.currentThread().getName() +"-----------------");
        return res;
    }

    // Place Rendezvous test code inside of the Rendezvous class.

    public static void rendezTest1() {
        final Rendezvous r1 = new Rendezvous();
        final Rendezvous r2 = new Rendezvous();
    
        //basic case
        KThread t1 = new KThread( new Runnable () {
            public void run() {
                int tag = 0;
                int send = 1;
    
                System.out.println ("Thread " + KThread.currentThread().getName() + " exchanging " + send);
                int recv = r1.exchange (tag, send);
                Lib.assertTrue (recv == 2, "Was expecting " + 2 + " but received " + recv);
                System.out.println ("Thread " + KThread.currentThread().getName() + " received " + recv);
            }
            });
        t1.setName("t1");
        KThread t2 = new KThread( new Runnable () {
            public void run() {
                int tag = 0;
                int send = 2;
    
                System.out.println ("Thread " + KThread.currentThread().getName() + " exchanging " + send);
                int recv = r1.exchange (tag, send);
                Lib.assertTrue (recv == 1, "Was expecting " + 1 + " but received " + recv);
                System.out.println ("Thread " + KThread.currentThread().getName() + " received " + recv);
            }
            });
        t2.setName("t2");

        //t3, t4: same tag, same rendezvous
        KThread t3 = new KThread( new Runnable () {
            public void run() {
                int tag = 0;
                int send = 3;
    
                System.out.println ("Thread " + KThread.currentThread().getName() + " exchanging " + send);
                int recv = r1.exchange (tag, send);
                Lib.assertTrue (recv == 4, "Was expecting " + 4 + " but received " + recv);
                System.out.println ("Thread " + KThread.currentThread().getName() + " received " + recv);
            }
            });
        t3.setName("t3");

        KThread t4 = new KThread( new Runnable () {
            public void run() {
                int tag = 0;
                int send = 4;
    
                System.out.println ("Thread " + KThread.currentThread().getName() + " exchanging " + send);
                int recv = r1.exchange (tag, send);
                Lib.assertTrue (recv == 3, "Was expecting " + 3 + " but received " + recv);
                System.out.println ("Thread " + KThread.currentThread().getName() + " received " + recv);
            }
            });
        t4.setName("t4");

        //t5, t6: different tag, same rendezvous
        KThread t5 = new KThread( new Runnable () {
            public void run() {
                int tag = 1;
                int send = 5;
    
                System.out.println ("Thread " + KThread.currentThread().getName() + " exchanging " + send);
                int recv = r1.exchange (tag, send);
                Lib.assertTrue (recv == 6, "Was expecting " + 6 + " but received " + recv);
                System.out.println ("Thread " + KThread.currentThread().getName() + " received " + recv);
            }
            });
        t5.setName("t5");

        KThread t6 = new KThread( new Runnable () {
            public void run() {
                int tag = 1;
                int send = 6;
    
                System.out.println ("Thread " + KThread.currentThread().getName() + " exchanging " + send);
                int recv = r1.exchange (tag, send);
                Lib.assertTrue (recv == 5, "Was expecting " + 5 + " but received " + recv);
                System.out.println ("Thread " + KThread.currentThread().getName() + " received " + recv);
            }
            });
        t6.setName("t6");

        //t7, t8: same tag, different rendezvous
        KThread t7 = new KThread( new Runnable () {
            public void run() {
                int tag = 1;
                int send = 7;
    
                System.out.println ("Thread " + KThread.currentThread().getName() + " exchanging " + send);
                int recv = r2.exchange (tag, send);
                Lib.assertTrue (recv == 8, "Was expecting " + 8 + " but received " + recv);
                System.out.println ("Thread " + KThread.currentThread().getName() + " received " + recv);
            }
            });
        t7.setName("t7");

        KThread t8 = new KThread( new Runnable () {
            public void run() {
                int tag = 1;
                int send = 8;
    
                System.out.println ("Thread " + KThread.currentThread().getName() + " exchanging " + send);
                int recv = r2.exchange (tag, send);
                Lib.assertTrue (recv == 7, "Was expecting " + 7 + " but received " + recv);
                System.out.println ("Thread " + KThread.currentThread().getName() + " received " + recv);
            }
            });
        t8.setName("t8");
    
        t1.fork(); t2.fork(); t3.fork(); t4.fork(); t5.fork(); t6.fork(); t7.fork(); t8.fork();
        // assumes join is implemented correctly
        t1.join(); t2.join(); t3.join(); t4.join(); t5.join(); t6.join(); t7.join(); t8.join();
    }
    
    // Invoke Rendezvous.selfTest() from ThreadedKernel.selfTest()

    public static void selfTest() {
        // place calls to your Rendezvous tests that you implement here
        rendezTest1();
    }
}
