package nachos.threads;

import java.util.*;
import java.util.function.IntSupplier;
import nachos.machine.*;

/**
 * A <i>Future</i> is a convenient mechanism for using asynchonous
 * operations.
 */
public class Future {
    private int result;
    private boolean is_completed = false;
    private Condition condVar; // condition variable
    private Lock compLock; //completed lock
    private Lock condLock; //condition lock
    /**
     * Instantiate a new <i>Future</i>.  The <i>Future</i> will invoke
     * the supplied <i>function</i> asynchronously in a KThread.  In
     * particular, the constructor should not block as a consequence
     * of invoking <i>function</i>.
     */
    private class FutureRunnable implements Runnable {
        private IntSupplier function;
        
        public FutureRunnable(IntSupplier function) {
            this.function = function;
        }

        public void run(){
            // compute the function
            //  and set 'is_completed' to be true
            compLock.acquire();
            int res = function.getAsInt();
            result = res;
            is_completed = true;
            compLock.release();
            // wake all threads in the queue
            condLock.acquire();
            condVar.wakeAll();
            condLock.release();
        }
    }

    public Future (IntSupplier function) {
        compLock = new Lock();
        condLock = new Lock();
        condVar = new Condition(condLock);
        FutureRunnable fr = new FutureRunnable(function);
        KThread thread = new KThread(fr);
        thread.fork();
    }

    
    /**
     * Return the result of invoking the <i>function</i> passed in to
     * the <i>Future</i> when it was created.  If the function has not
     * completed when <i>get</i> is invoked, then the caller is
     * blocked.  If the function has completed, then <i>get</i>
     * returns the result of the function.  Note that <i>get</i> may
     * be called any number of times (potentially by multiple
     * threads), and it should always return the same value.
     */
    public int get() {
        compLock.acquire();
        if(is_completed){
            compLock.release();
            return result;
        }else{
            //function hasn't completed,block
            compLock.release();
            condLock.acquire();
            condVar.sleep();
            condLock.release();
            return result;
        }
    }

    //just return a value
    public static void futureTest1(){
        IntSupplier getInt = () -> 2;
        Future f1 = new Future(getInt);
        int res = f1.get();
        System.out.printf("result: %d",res);
        Lib.assertTrue(f1.get()==2,"Future error:Wrong Integer, the answer supposes to be 2");
    }
    
    public static void futureTest2(){
        IntSupplier getInt = () -> 2;
        Future f2 = new Future(getInt);
        int res = f2.get();
        KThread th1 = new KThread(new Runnable(){
            public void run(){
                Lib.assertTrue(f2.get()==res,"Future error: the results from different thread don't match");
                System.out.printf("the result should be: %d",res);
            }
        }
        ).setName("Thread1");
    }

    //multiple threads
    public static void futureTest3(){
        IntSupplier getInt = () -> 20;
        Future f3 = new Future(getInt);
        int res = f3.get();
        KThread child1 = new KThread(new Runnable(){
            public void run(){
                Lib.assertTrue(f3.get()==res,"Future error: the results from different thread don't match");
                System.out.printf("the result should be: %d",res);
            }
        });
        child1.setName("child1").fork();
    }

    public static void selfTest(){
        futureTest1();
        futureTest2();
        futureTest3();
    }



}
