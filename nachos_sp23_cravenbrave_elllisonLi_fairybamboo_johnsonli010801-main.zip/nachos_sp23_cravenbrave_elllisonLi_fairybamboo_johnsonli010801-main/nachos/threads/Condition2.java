package nachos.threads;

import nachos.machine.*;

import java.util.LinkedList;
import java.util.Queue;
/**
 * An implementation of condition variables that disables interrupt()s for
 * synchronization.
 * 
 * <p>
 * You must implement this.
 * 
 * @see nachos.threads.Condition
 */
public class Condition2 {
	/**
	 * Allocate a new condition variable.
	 * 
	 * @param conditionLock the lock associated with this condition variable.
	 * The current thread must hold this lock whenever it uses <tt>sleep()</tt>,
	 * <tt>wake()</tt>, or <tt>wakeAll()</tt>.
	 */
	public Condition2(Lock conditionLock) {
		this.conditionLock = conditionLock;
		//using a queue to hold the thread that is block on lock.
		this.threadOnWait = new LinkedList<KThread>();
        this.sleepForQueue = new LinkedList<KThread>();
	}

	/**
	 * Atomically release the associated lock and go to sleep on this condition
	 * variable until another thread wakes it using <tt>wake()</tt>. The current
	 * thread must hold the associated lock. The thread will automatically
	 * reacquire the lock before <tt>sleep()</tt> returns.
	 */
	public void sleep() {
		Lib.assertTrue(conditionLock.isHeldByCurrentThread());
		//to disable the interrupt.
		//Reference:P() function from Semaphore.java
		boolean intStatus = Machine.interrupt().disable();
		conditionLock.release();
		
		threadOnWait.add(KThread.currentThread());
		//now make the current KThread to sleep
		KThread.currentThread().sleep();
		
		conditionLock.acquire();
        //restore the interrupt
		Machine.interrupt().restore(intStatus);
	}

	/**
	 * Wake up at most one thread sleeping on this condition variable. The
	 * current thread must hold the associated lock.
	 */
	public void wake() {
		Lib.assertTrue(conditionLock.isHeldByCurrentThread());
		//make sure the sleepKernelThread queue is not empty first
		if(!threadOnWait.isEmpty())
		{
			//Reference from Semaphore class v() function
			//disable the interrupt.
			boolean intStatus = Machine.interrupt().disable();
			KThread waitThread = threadOnWait.poll();
			//for test
			System.out.println(waitThread.getName()+" is woken");

            if(sleepForQueue.contains(waitThread)) {
    			ThreadedKernel.alarm.cancel(waitThread);
                sleepForQueue.remove(waitThread);
            } else {
                waitThread.ready();
            }
            
			//restore the interrupt
			Machine.interrupt().restore(intStatus);
		}
	}

	/**
	 * Wake up all threads sleeping on this condition variable. The current
	 * thread must hold the associated lock.
	 */
	public void wakeAll() {
		Lib.assertTrue(conditionLock.isHeldByCurrentThread());
		
        //disable the interrupt before wakeall sleeping threads
        boolean intStatus = Machine.interrupt().disable();
		//recall the wake function to wake all onwait Threads.
		
		while(!this.threadOnWait.isEmpty())
		{
			wake();
		}
        //restore the interrupt after all sleeping threads are woken.
        Machine.interrupt().restore(intStatus);
		
	}

    /**
	 * Atomically release the associated lock and go to sleep on
	 * this condition variable until either (1) another thread
	 * wakes it using <tt>wake()</tt>, or (2) the specified
	 * <i>timeout</i> elapses.  The current thread must hold the
	 * associated lock.  The thread will automatically reacquire
	 * the lock before <tt>sleep()</tt> returns.
	 */
    public void sleepFor(long timeout) {
		Lib.assertTrue(conditionLock.isHeldByCurrentThread());
		
        boolean intStatus = Machine.interrupt().disable();

		//release associated lock
		conditionLock.release();
		//add the currentThread to the wait queue
		KThread sleptThread = KThread.currentThread();
        sleepForQueue.add(sleptThread);
        threadOnWait.add(sleptThread);
		//call waitUntil function to set the timeout on current Thread
		//since waitUntil works the same as sleepFor function.(From piazza)
		ThreadedKernel.alarm.waitUntil(timeout);
        
        //timeout, manully remove waitthread
        if(threadOnWait.contains(sleptThread)) {
            threadOnWait.remove(sleptThread);
        }

        if(sleepForQueue.contains(sleptThread)) {
            sleepForQueue.remove(sleptThread);
        }

		//reacquire the lock
		conditionLock.acquire();
        Machine.interrupt().restore(intStatus);
	}

    private Lock conditionLock;
	private Queue<KThread> threadOnWait;
    private Queue<KThread> sleepForQueue;

	// Place Condition2 testing code in the Condition2 class.
    // Example of the "interlock" pattern where two threads strictly
    // alternate their execution with each other using a condition
    // variable.  (Also see the slide showing this pattern at the end
    // of Lecture 6.)
    private static class InterlockTest {
        private static Lock lock;
        private static Condition2 cv;

        private static class Interlocker implements Runnable {
            public void run () {
                lock.acquire();
                for (int i = 0; i < 10; i++) {
                    System.out.println(KThread.currentThread().getName());
                    cv.wake();   // signal
                    cv.sleep();  // wait
                }
                lock.release();
            }
        }

        public InterlockTest () {
            lock = new Lock();
            cv = new Condition2(lock);

            KThread ping = new KThread(new Interlocker());
            ping.setName("ping");
            KThread pong = new KThread(new Interlocker());
            pong.setName("pong");

            ping.fork();
            pong.fork();

            // We need to wait for ping to finish, and the proper way
            // to do so is to join on ping.  (Note that, when ping is
            // done, pong is sleeping on the condition variable; if we
            // were also to join on pong, we would block forever.)
            // For this to work, join must be implemented.  If you
            // have not implemented join yet, then comment out the
            // call to join and instead uncomment the loop with
            // yields; the loop has the same effect, but is a kludgy
            // way to do it.
            ping.join();
        }
    }

	// Place Condition2 test code inside of the Condition2 class.

    // Test programs should have exactly the same behavior with the
    // Condition and Condition2 classes.  You can first try a test with
    // Condition, which is already provided for you, and then try it
    // with Condition2, which you are implementing, and compare their
    // behavior.

    // Do not use this test program as your first Condition2 test.
    // First test it with more basic test programs to verify specific
    // functionality.
    public static void cvTest5() {
        final Lock lock = new Lock();
        final Condition2 empty = new Condition2(lock);
        final LinkedList<Integer> list = new LinkedList<>();

        KThread consumer = new KThread( new Runnable () {
                public void run() {
                    lock.acquire();
                    while(list.isEmpty()){
                        empty.sleep();
                    }
                    Lib.assertTrue(list.size() == 5, "List should have 5 values.");
                    while(!list.isEmpty()) {
                        // context swith for the fun of it
                        KThread.currentThread().yield();
                        System.out.println("Removed " + list.removeFirst());
                    }
                    lock.release();
                }
            });

        KThread producer = new KThread( new Runnable () {
                public void run() {
                    lock.acquire();
                    for (int i = 0; i < 5; i++) {
                        list.add(i);
                        System.out.println("Added " + i);
                        // context swith for the fun of it
                        KThread.currentThread().yield();
                    }
                    empty.wake();
                    lock.release();
                }
            });

        consumer.setName("Consumer");
        producer.setName("Producer");

        consumer.fork();
        producer.fork();

        // We need to wait for the consumer and producer to finish,
        // and the proper way to do so is to join on them.  For this
        // to work, join must be implemented.  If you have not
        // implemented join yet, then comment out the calls to join
        // and instead uncomment the loop with yield; the loop has the
        // same effect, but is a kludgy way to do it.
        consumer.join();
        producer.join();
    }
    
    // Place sleepFor test code inside of the Condition2 class.
    private static void sleepForTest1 () {
		Lock lock = new Lock();
		Condition2 cv = new Condition2(lock);
	
		lock.acquire();
		long t0 = Machine.timer().getTime();
		System.out.println (KThread.currentThread().getName() + " sleeping");
		// no other thread will wake us up, so we should time out
		cv.sleepFor(2000);
		long t1 = Machine.timer().getTime();
		System.out.println (KThread.currentThread().getName() +
					" woke up, slept for " + (t1 - t0) + " ticks");
		lock.release();
	}

    private static void sleepForTest2 () {
        Lock lock = new Lock();
        Condition2 cv = new Condition2(lock);

        KThread thread1 = new KThread(new Runnable() {
            public void run() {
                lock.acquire();
                System.out.println("I'm thread1");
                cv.sleepFor(50000);
                System.out.println("Thread1 wake");
                lock.release();
            }
        });
        thread1.setName("thread1");

        KThread thread2 = new KThread(new Runnable() {
           public void run() {
                lock.acquire();
                System.out.println("I'm thread2");
                cv.sleepFor(60000);
                System.out.println("Thread2 wake");
                lock.release();
           } 
        });
        thread2.setName("thread2");

        KThread thread4 = new KThread(new Runnable() {
           public void run() {
                lock.acquire();
                System.out.println("I'm thread4");
                cv.sleep();
                System.out.println("Thread4 wake");
                lock.release();
           } 
        });
        thread4.setName("thread4");

        KThread thread3 = new KThread(new Runnable() {
            public void run() {
                lock.acquire();
                System.out.println("Thread3 is running");
                cv.wakeAll();
                lock.release();
                System.out.println("Current time is " + Machine.timer().getTime());
            }
        });
        thread3.setName("thread3");


        thread1.fork();
        
        thread2.fork();
        thread4.fork();
        thread3.fork();

        thread1.join();
        thread2.join();
        thread4.join();
        thread3.join();
    }

    public static void selfTest() {
        //new InterlockTest();

		//sleepForTest1();
        // sleepForTest2();
		//cvTest5();
    }
}
