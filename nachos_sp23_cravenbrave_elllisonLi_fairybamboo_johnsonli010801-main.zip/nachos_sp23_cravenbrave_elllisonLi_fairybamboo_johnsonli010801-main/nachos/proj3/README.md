In project 3, our team members collaborated to implement the functions in VMProcess and VMKernel.java files. Indeed, what we have done is to extend the super class UserKernel and UserProcess,
and take control of implementing the page fault handling and also read and write in virtual memory.
>
Contribution:
Johnson Li: helping to debug page fault section and also test for clock algorithm.
Zhuyu Hu: implemented new 'readVirtualMemory' method.
Yuzeng Li: implement handlePagefault and related methods.
Wenyi Liu: implement writeVirtualMemory and clockAlgorithm methods.
