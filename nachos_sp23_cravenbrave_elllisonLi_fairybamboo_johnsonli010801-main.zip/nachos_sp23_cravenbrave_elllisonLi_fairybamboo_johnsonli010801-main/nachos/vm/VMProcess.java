package nachos.vm;

import java.util.Arrays;
import java.util.HashMap;

import javax.print.attribute.standard.PagesPerMinute;

import nachos.machine.*;
import nachos.threads.*;
import nachos.userprog.*;
import nachos.vm.*;

/**
 * A <tt>UserProcess</tt> that supports demand-paging.
 */
public class VMProcess extends UserProcess {
	/**
	 * Allocate a new process.
	 */
	public VMProcess() {
		super();
	}

	/**
	 * Save the state of this process in preparation for a context switch.
	 * Called by <tt>UThread.saveState()</tt>.
	 */
	public void saveState() {
		super.saveState();
	}

	/**
	 * Restore the state of this process after a context switch. Called by
	 * <tt>UThread.restoreState()</tt>.
	 */
	public void restoreState() {
		super.restoreState();
	}

	/**
	 * Initializes page tables for this process so that the executable can be
	 * demand-paged.
	 * 
	 * @return <tt>true</tt> if successful.
	 */
	protected boolean loadSections() {
		UserProcess.loadLock.acquire();

		//the index represents the vpn of each translationentry
		pageTable = new TranslationEntry[numPages];

		System.out.println("NumPage: " + numPages); //27
		
		int processPages = 0;

		for(int i = 0; i < coff.getNumSections(); ++i) {
			CoffSection section = coff.getSection(i);

			for(int j = 0; j < section.getLength(); ++j) {
				int vpn = section.getFirstVPN() + j;
				pageTable[vpn] = new TranslationEntry(-1, -1, false, section.isReadOnly(), false, false);
				processPages = vpn;
			}
		}

		System.out.println("Vpn: " + processPages); //0 - 17

		for(int vpn = processPages + 1; vpn < numPages; vpn++) {
			pageTable[vpn] = new TranslationEntry(-1, -1, false, false, false, false);
			processPages = vpn;
		}

		System.out.println("processPages: " + processPages); //18 - 26
		
		//size of pagetable == 27
		UserProcess.loadLock.release();
		return true;	
	}

	/**
	 * Release any resources allocated by <tt>loadSections()</tt>.
	 */
	protected void unloadSections() {
		System.out.println("SwapFileSize before: " + VMKernel.swapFilePageNum.size());
		for(int i = 0; i < pageTable.length; i++) {
			if(pageTable[i].vpn != -1) {
				VMKernel.swapFilePageNum.add(pageTable[i].vpn);
			}
		}
		System.out.println("SwapFileSize after: " + VMKernel.swapFilePageNum.size());
		super.unloadSections();
	}
	
	/**
	 * Transfer data from this process's virtual memory to the specified array.
	 * This method handles address translation details. This method must
	 * <i>not</i> destroy the current process if an error occurs, but instead
	 * should return the number of bytes successfully copied (or zero if no data
	 * could be copied).
	 * 
	 * @param vaddr the first byte of virtual memory to read.
	 * @param data the array where the data will be stored.
	 * @param offset the first byte to write in the array.
	 * @param length the number of bytes to transfer from virtual memory to the
	 * array.
	 * @return the number of bytes successfully transferred.
	 */
	public int readVirtualMemory(int vaddr, byte[] data, int offset, int length){
		//check valid offset
		Lib.assertTrue(offset >= 0 && length >= 0 && offset + length <= data.length);

		System.out.println("readvirtualmem running");

		byte[] memory = Machine.processor().getMemory();

		//check vaddr
		if (vaddr < 0 || vaddr > pageTable.length * pageSize) {
			return 0;
		}

		int totalBytes = 0;
		int currNumBytes = 0;
		int currentVaddr = vaddr;
		
		while(totalBytes < length) {
			int currVPN = Processor.pageFromAddress(currentVaddr);

			if(currVPN >= numPages) {
				return totalBytes;
			}

			if(!pageTable[currVPN].valid) {
				handlePageFault(currVPN);
			}
			
			VMKernel.pinMap.replace(pageTable[currVPN], true);

			int currPPN = pageTable[currVPN].ppn;

			int off = Processor.offsetFromAddress(currentVaddr);
			int phyAddr = Machine.processor().makeAddress(currPPN,off);

			if(phyAddr < 0 || phyAddr >= memory.length) {
				unPinned(pageTable[currVPN]);
				return totalBytes;
			}

			currNumBytes = Math.min(length - totalBytes, pageSize - off);
			System.arraycopy(memory,phyAddr,data,offset,currNumBytes);

			unPinned(pageTable[currVPN]);

			currentVaddr += currNumBytes;
			totalBytes += currNumBytes;
			offset += currNumBytes;		
		}

		return totalBytes;
	}

	/**
	 * Transfer data from the specified array to this process's virtual memory.
	 * This method handles address translation details. This method must
	 * <i>not</i> destroy the current process if an error occurs, but instead
	 * should return the number of bytes successfully copied (or zero if no data
	 * could be copied).
	 * 
	 * @param vaddr the first byte of virtual memory to write.
	 * @param data the array containing the data to transfer.
	 * @param offset the first byte to transfer from the array.
	 * @param length the number of bytes to transfer from the array to virtual
	 * memory.
	 * @return the number of bytes successfully transferred.
	 */
	public int writeVirtualMemory(int vaddr, byte[] data, int offset, int length) {
		Lib.assertTrue(offset >= 0 && length >= 0
				&& offset + length <= data.length);

		System.out.println("writeVirtualMem");

		byte[] memory = Machine.processor().getMemory();

		if (vaddr < 0 || vaddr > pageTable.length * pageSize) {
			return 0;
		}
		int currentVaddr = vaddr;
		int totalBytes=0;

		while(totalBytes < length) {
			int currVPN = Processor.pageFromAddress(currentVaddr);
			if(currVPN >= numPages) {
				return 0;
			}

			if(!pageTable[currVPN].valid){
				handlePageFault(currVPN);
			}

			VMKernel.pinMap.replace(pageTable[currVPN], true);
			int currPPN = pageTable[currVPN].ppn;

			int newOffset = Processor.offsetFromAddress(currentVaddr);
			int currPaddr = Processor.makeAddress(currPPN, newOffset);
			
			// check paddr
			if (currPaddr < 0 || currPaddr >= memory.length) {
				// release pin when error occur
				unPinned(pageTable[currVPN]);
				return totalBytes;
			}

			if(pageTable[currVPN].readOnly) {
				unPinned(pageTable[currVPN]);
				return totalBytes;
			}

			//bytes to read, page size - offset means the bytes left in this page
			//read the whole left page or length, whichever is smaller
			int amount = Math.min(length - totalBytes, pageSize - newOffset);
			System.arraycopy(data, offset, memory, currPaddr, amount);

			unPinned(pageTable[currVPN]);
			pageTable[currVPN].dirty = true;
			
			currentVaddr += amount;
			currPaddr = pageSize * currPPN + newOffset;

			offset += amount;
			totalBytes += amount;
		}

		return totalBytes;
	}

	private void handlePageFault(int badVpn) {
		VMKernel.pageFaultLock.acquire();
		int ppn = -1;
		
		if(UserKernel.pagesFree.size() == 0) {
			System.out.println("VM does not have free pages.");
			ppn = VMKernel.clockAlgorithm();
			
			if(VMKernel.physicalPages[ppn].dirty) {
				swapOut(ppn);
			}

			VMKernel.physicalPages[ppn].valid = false;
			// findPages(ppn).valid = false;
		} else {
			System.out.println("VM has free pages." + UserKernel.pagesFree.size());
			ppn = UserKernel.pagesFree.getFirst();
			UserKernel.pagesFree.removeFirst();
		}

		pageTable[badVpn].ppn = ppn;

		if(pageTable[badVpn].vpn != -1) {
			System.out.println("swap in");
			swapIn(badVpn, ppn);
		} else {
			System.out.println("find section");
			findSection(badVpn, pageTable[badVpn].ppn);
		}

		VMKernel.physicalPages[ppn] = pageTable[badVpn];

		System.out.println("VM physicalPages" + ppn + ":"+ VMKernel.physicalPages[ppn]);
		pageTable[badVpn].valid = true;
		VMKernel.pageFaultLock.release();
	}
	
	/**
	 * Handle a user exception. Called by <tt>UserKernel.exceptionHandler()</tt>
	 * . The <i>cause</i> argument identifies which exception occurred; see the
	 * <tt>Processor.exceptionZZZ</tt> constants.
	 * 
	 * @param cause the user exception that occurred.
	 */
	public void handleException(int cause) {
		Processor processor = Machine.processor();
		System.out.println("VM Process exception handler");
		switch (cause) {
		case Processor.exceptionPageFault:
			int badAddr = processor.readRegister(Processor.regBadVAddr);
			int badVpn = Processor.pageFromAddress(badAddr);
			handlePageFault(badVpn);
			break;
		default:
			super.handleException(cause);
			break;
		}
	}

	private void swapIn(int vpn, int ppn) {
		int spn = pageTable[vpn].vpn;
		VMKernel.swapFile.read(spn*pageSize, Machine.processor().getMemory(), Processor.makeAddress(ppn, 0), pageSize);
	}

	private void swapOut(int ppn) {
		int spn = 0;
		
		spn = VMKernel.swapNum++;


		VMKernel.swapFile.write(spn*pageSize, Machine.processor().getMemory(), Processor.makeAddress(ppn, 0), pageSize);

		VMKernel.physicalPages[ppn].vpn = spn;
		VMKernel.physicalPages[ppn].dirty = false;
		// findPages(ppn).vpn = spn;
		// findPages(ppn).dirty = false;
	}

	private void findSection(int vpn, int ppn) {
		boolean isCoff = false;
		int vpn_num = 0;
	
		for(int i = 0; i < coff.getNumSections(); i++) {
			CoffSection section = coff.getSection(i);
			for(int j = 0; j < section.getLength(); j++) {
				vpn_num = section.getFirstVPN() + j;
				if(vpn_num == vpn) {
					section.loadPage(j, ppn);
					isCoff = true;
					break;
				}
			}
		}

		if(!isCoff) {
			for(int i = vpn_num + 1; i < numPages; i++) {
				if(pageTable[i].vpn != -1) {
					Arrays.fill(Machine.processor().getMemory(), Processor.makeAddress(ppn, 0), Processor.makeAddress(ppn, 0) + pageSize, (byte) 0);
				}
			}
		}
	}

	private void unPinned(TranslationEntry entry) {
		VMKernel.pinMap.replace(entry, false);
		VMKernel.lock.acquire();
		VMKernel.CV.wake();
		VMKernel.lock.release();
	}

	private TranslationEntry findPages(int ppn) {
		for(int i = 0; i < pageTable.length; ++i) {
			if(pageTable[i].ppn == ppn) {
				return pageTable[i];
			}
		}
		return null;
	}
	
	private static final int pageSize = Processor.pageSize;

	private static final char dbgProcess = 'a';

	private static final char dbgVM = 'v';
	private HashMap<Integer, Integer> vpnToSpn;

}
