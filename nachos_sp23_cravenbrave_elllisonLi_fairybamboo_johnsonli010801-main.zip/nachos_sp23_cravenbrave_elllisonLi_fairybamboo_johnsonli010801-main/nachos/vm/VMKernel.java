package nachos.vm;

import java.util.HashMap;
import java.util.LinkedList;

import nachos.machine.*;
import nachos.threads.*;
import nachos.userprog.*;
import nachos.vm.*;

/**
 * A kernel that can support multiple demand-paging user processes.
 */
public class VMKernel extends UserKernel {
	/**
	 * Allocate a new VM kernel.
	 */
	public VMKernel() {
		super();
		numPhysicalPages = Machine.processor().getNumPhysPages();
		
		System.out.println("numPhyPages: " + numPhysicalPages);

		//the index represents the ppn of each translationEntry
		physicalPages = new TranslationEntry[numPhysicalPages];
		
		//for clockAlgorithm
		visited = new boolean[numPhysicalPages];	
		clockHand = 0;
	}

	/**
	 * Initialize this kernel.
	 */
	public void initialize(String[] args) {
		super.initialize(args);
		swapFile = Machine.stubFileSystem().open("swap.txt", true);
		lock = new Lock();
		CV = new Condition(lock);
		pageFaultLock = new Lock();
	}

	/**
	 * Test this kernel.
	 */
	public void selfTest() {
		super.selfTest();
	}

	/**
	 * Start running user programs.
	 */
	public void run() {
		super.run();
	}

	/**
	 * Terminate this kernel. Never returns.
	 */
	public void terminate() {
		swapFile.close();
		super.terminate();
	}

	public static int clockAlgorithm() {
		int victim = -1;
		int numPinnedPages = 0;
		lock.acquire();
		System.out.println("Clock working");
		
		for(int i = 0; i < numPhysicalPages; ++i) {
			pinMap.put(physicalPages[i], false);
		}

		while (true) {
			//if the clock hand points to a pinned page, then skip it
			System.out.println("ClockHand: " + clockHand);

			System.out.println(physicalPages[clockHand]);
			
			if (pinMap.get(physicalPages[clockHand])) {
				numPinnedPages++;
				//clockhand == physicalPages[clockHand].ppn;
				System.out.println("page: " + physicalPages[clockHand].vpn + "used");
				//if all pages are pinned, then sleep
				if (numPinnedPages == numPhysicalPages) {
					System.out.println("All pages used");	

					CV.sleep();
					//reset after wake up 
					// numPinnedPages = 0; NOT SURE
					numPinnedPages --;
				}
			} else { //find a non-pinned page to evict
				//if the clock hand swept for one round, and it's not pinned
				//then evict it
				if (visited[clockHand]==true) {
					victim = clockHand;
					//reset visited and point to the next page
					visited[clockHand] = false;
					clockHand = (clockHand + 1) % numPhysicalPages;
					lock.release();
					return Math.floorMod(victim,numPhysicalPages);
					// return victim;
				}

			}
			visited[clockHand] = true;
			clockHand = (clockHand + 1) % numPhysicalPages;
		}
		// return victim;
	}

	// dummy variables to make javac smarter
	private static VMProcess dummy1 = null;
	private static final char dbgVM = 'v';

	//used for clock algorithm
	private static int clockHand;
	public static TranslationEntry[] physicalPages;//name
	private static boolean[] visited;
	public static int numPhysicalPages;

	public static LinkedList<Integer> swapFilePageNum; 

	public static int sfpnLen;
	public static OpenFile swapFile;

	protected static Lock pageFaultLock;
	//used for lock
	public static Lock lock;
	public static Condition CV;

	public static HashMap<TranslationEntry, Boolean> pinMap = new HashMap<>();

	protected static int swapNum = 0; 
}
