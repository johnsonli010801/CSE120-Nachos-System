
Description:
We follow the instruction and finish KThread, Alarm, Condition2, Rendezvous, and Future class. All required methods seem to perform well based on our tests. 
For tests, we try to consider about different possibilities that could occure. For instance, there are several cases of the sleepFor method in Condition2 class. 
We can have a thread that is waked up by the wake() method. If no other threads try to wake it up, the thread can also be waked up by the time interrupter 
if the time is out. 

Yuzeng Li finish waitUntil and timeInterrupt in Alarm class and modify condition2 sleepFor method. 
>
Johnson Li finished implementation of Condition2 class and considered serveral cases of testing for Condition2 class.

Wenyi Liu is in charge of the Redezvous class implementation and testing, and cancel function in the Alarm class. She also modified a minor part of waitUnitil and timeInterrupt in the Alarm class.

Zhuyu Hu finish the future class implementation and testing.
